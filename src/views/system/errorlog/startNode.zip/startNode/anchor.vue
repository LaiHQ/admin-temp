<template>
        <div @click.stop="handleClick" class="anchor" :class="className" :style="{ width: width + 'px', height: height + 'px' }"></div>
</template>

<script setup>
import { ref,onMounted,reactive } from 'vue';

const props = defineProps({   
    width: {
        type: Number,
        default: 10,
    },
    height: {
        type: Number,
        default: 10,
    },
    className: {
        type: String,
        default: '',
    },
});

const handleClick = () => {
    console.log('click');
}
</script>

<style lang="less" scoped>
.anchor {
    width: 100%;
    height: 100%;
    background-color: #1890ff;
    border-radius: 50%;
    border: 2px solid #fff;
    cursor: pointer;
    position: relative;
    box-sizing: border-box;
    transition: all 0.2s;
}

.anchor:hover {
    background-color: #40a9ff;
    transform: scale(1.2);
}

.incomming-anchor {
    background-color: #ff4d4f;
}

.incomming-anchor:hover {
    background-color: #ff7875;
}

.outgoing-anchor {
    background-color: #52c41a;
}

.outgoing-anchor:hover {
    background-color: #73d13d;
}
</style>