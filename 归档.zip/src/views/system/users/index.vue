<!--
 * @Date: 2023-06-18 22:53:05
 * @LastEditors: lai_hq@qq.com
 * @LastEditTime: 2023-06-18 22:53:55
 * @FilePath: \apph5f:\code\yideCode\temp\admin-temp\src\views\system\users\index.vue
-->
<template>
    <div>users</div>
</template>

<script setup></script>

<style lang="less" scoped></style>
