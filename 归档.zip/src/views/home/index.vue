<template>
    <div class="home">
        <a-button type="primary">Primary</a-button>
    </div>
</template>

<script setup>
// import {getSystemRouter} from "@/api"

// http.get("/system/menu/getRouters",{}).then((res) => {
//     console.log(res)
// })

// getSystemRouter().then(res=>{
//     console.log(res)
// })
</script>

<style scoped>
.home {
    height: calc(100vh - 120px);
}
</style>
