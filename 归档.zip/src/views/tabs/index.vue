<template>
    <div class="container">
        <RouteTabs />
    </div>
</template>

<script setup>
import RouteTabs from "@/components/routeTabs/index.vue"
</script>

<style lang="less" scoped>
.container {
    position: relative;
}
</style>
