<!--
 * @Descripttion: 
 * @version: 1.0.0
 * @Author: lai_hq@qq.com
 * @Date: 2023-03-07 11:39:38
 * @LastEditors: lai_hq@qq.com
 * @LastEditTime: 2023-03-07 11:40:05
-->
<template>
    <router-view></router-view>
</template>
