import { defineConfig } from "vite"

export default defineConfig({
    server: {
        port: 8090,
        host: "0.0.0.0"
    },
    plugins: []
})
